from django.http import HttpResponse
from newapp.models import Board
from django.views.decorators.csrf import csrf_exempt
from django.shortcuts import render
def home(request):
    return render(request, 'home.html')

@csrf_exempt
def add(request):
	name=request.POST['name']
	desc=request.POST['desc']
	board = Board(name=name, description=desc)
	board.save()
	return HttpResponse('data added')

def view_board(request):
    boards = Board.objects.all()
    return render(request, 'view.html', {'boards': boards})

def load_form(request):
    return render(request, 'add_board.html')


